{{ name }}
{{ underline }}

.. currentmodule:: {{ module }}

.. autofunction:: {{ objname }}

